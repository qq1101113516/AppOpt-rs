wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 9
	done
}
wait_sys_boot_completed
MODDIR=${0%/*}
cd $MODDIR
killall -15 AppOpt
#nohup ${MODDIR}/AppOpt >/dev/null 2>&1 &
nohup ${MODDIR}/AppOpt -w -b MyAppOpt >/dev/null 2>&1 &
for MAX_CPUS in /sys/devices/system/cpu/cpu*/core_ctl/max_cpus; do
	if [ -e "$MAX_CPUS" ] && [ "$(cat $MAX_CPUS)" != "$(cat ${MAX_CPUS%/*}/min_cpus)" ]; then
		chmod a+w "${MAX_CPUS%/*}/min_cpus"
		echo "$(cat $MAX_CPUS)" > "${MAX_CPUS%/*}/min_cpus"
		chmod a-w "${MAX_CPUS%/*}/min_cpus"
	fi
done

# 如需暂停绿厂oiface请将下面23行的#号注释删掉，恢复则将0改成1
# [ -n "$(getprop persist.sys.oiface.enable)" ] && setprop persist.sys.oiface.enable 0
#stop oiface
stop vendor.msm_irqbalance
# 如需禁用米系机型joyose请将下面26行pm命令前的#号删掉
# pm disable-user com.xiaomi.joyose; pm clear com.xiaomi.joyose

echo 25000 > /proc/sys/kernel/sched_rt_runtime_us
echo 26000 > /proc/sys/kernel/sched_rt_period_us
echo 25000 > /proc/sys/kernel/sched_rt_runtime_us
echo 4 > /proc/sys/kernel/sched_rr_timeslice_ms