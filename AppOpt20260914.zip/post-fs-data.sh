#!/system/bin/sh
MODDIR=${0%/*}

[ -f "$MODDIR/AppOpt.ko" ] || exit 0

if [ -f "$MODDIR/.boot" ]; then
    touch "$MODDIR/disable"
    rm -f "$MODDIR/.boot"
else
    touch "$MODDIR/.boot"
    insmod "$MODDIR/AppOpt.ko" >/dev/null 2>&1
    rm -f "$MODDIR/.boot"
fi
